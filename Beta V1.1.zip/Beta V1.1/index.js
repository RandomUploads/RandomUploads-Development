const Discord = require("discord.js");
const fs = require("fs");


const client = new Discord.Client();
const config = require("./config.js");
client.config = config;
client.queue = new Map()

fs.readdir("./events/", (err, files) => {
  if (err) return console.error(err);
  files.forEach(file => {
    const event = require(`./events/${file}`);
    let eventName = file.split(".")[0];
    client.on(eventName, event.bind(null, client));
  });
});

client.commands = new Discord.Collection()

fs.readdir("./commands/", (err, files) => {
  if (err) return console.error(err);
  files.forEach(file => {
    if (!file.endsWith(".js")) return;
    let props = require(`./commands/${file}`);
    let commandName = file.split(".")[0];
    client.commands.set(commandName, props);
  });
});

client.login(config.token);

  client.on ('message', async message => {
        if (message.author.bot) return;
    if(message.content.toLowerCase() === 'cat'){
        message.channel.send('MEOW MEOW MEOW MEOW MEOW')
     return message.react(":cat2:")
    }
    if(message.content.toLowerCase() == 'bye'){
     message.channel.send('<a:wave:773927372847579176>') 
      return message.react("<a:wave:773927372847579176>")
    }
    if(message.content.toLowerCase() == 'rick'){
       message.channel.send('https://www.youtube.com/watch?v=dQw4w9WgXcQ') 
     return message.react("<<a:rickroll:773941923383214102>")
    }
    if(message.content.toLowerCase() == 'cool'){
        message.channel.send('too cool for school') 
    return message.react(":thumbsup:")
    }
    if(message.content.toLowerCase() == 'lol'){
        return message.react("🤣")
    }
    if(message.content.toLowerCase() == 'oof'){
        message.react("<a:oof:774232327614103582>")
     return message.channel.send('oof!') 
    } 
    if(message.content.toLowerCase() == 'xd'){
       return message.react("XDDDDDDDDD")
    }
    if(message.content == 'pooping'){
     return message.react("https://tenor.com/view/rhino-pooping-enormous-gross-gif-5595661")
    }
    if(message.content == 'creator'){
     return message.channel.send("Built by RandomUploads :thumbsup:")
    }
    if(message.content == 'creator'){
     return message.channel.send("Built off python and js by RandomUploads :thumbsup:")
    if(message.content == 'shitpost'){
        return message.channel.send("https://tenor.com/view/rhino-pooping-enormous-gross-gif-5595661")
    }
    
    }
    if(message.content.toLowerCase() == 'ur mom'){
       return message.channel.send('Lmfao wut') 
    }
    if (message.content.toLowerCase() === 'ping') {  
       message.channel.send(`🏓Latency is ${Date.now() - message.createdTimestamp}ms. API Latency is ${Math.round(client.ws.ping)}ms`);
    }
    if(message.content.toLowerCase() == 'f'){
        return message.reply('rip you payed Your Respect!')   
    }
    if(message.content == 'good job'){
        return message.react(':thumbsup:') 
    }
    if(message.content.toLowerCase() == 'rip'){
    return message.react("<a:rip:774233181884514335>")
    }
    if(message.content.toLowerCase() == 'butt'){
        return message.channel.send("https://tenor.com/view/smack-that-booty-massage-gif-13340994")
    }
    if(message.content.includes('<@731721433515950080>')){
         message.react("<a:whyping:774183987937542185>")
    }
    if(message.content.includes('randomuploads')){
        message.react(":wave:")
    }
    if(message.content.toLowerCase() == 'hi'){
        return message.reply('Hello https://tenor.com/view/waving-pikachu-gif-cute-hi-gif-15583157') 
    }
    if(message.content.toLowerCase() == 'hello'){
        return message.reply('Hello https://tenor.com/view/waving-pikachu-gif-cute-hi-gif-15583157') 
    }

});
   client.on('message', message => { 
         if (message.author.bot) return;
    if (message.content.toLowerCase() == 'rps') {
      const whatyouget = ["scissors :scissors:", "paper :newspaper2:", "rock :shell:"] 
  const playergets = whatyouget[Math.floor(Math.random() * whatyouget.length)]; 
      const whatbotget = ["scissors :scissors:", "paper :newspaper2:", "rock :shell:"] 
  const botgets = whatbotget[Math.floor(Math.random() * whatbotget.length)]; 
   
  
  let embed = new Discord.MessageEmbed()
  .setTitle("RPS :scissors:/ :newspaper2:/ :shell:")
  .setDescription("Who will win " + message.author.username + " or  Bot")
  .addField("Bot got",botgets)
  .addField(message.author.username + " got", playergets)
  .setColor("RANDOM")
  if (botgets == playergets) {
          const wow = client.emojis.cache.find(emoji => emoji.name === "spongebobdancepants");
      embed.addField("Its a tie",wow)
  
  }
      
  if (botgets == "paper :newspaper2:" && playergets == "rock :shell:") {
      embed.addField("Rock Beats paper " + message.author.username + " wins",":sunglasses:")
  
  }
      
      if (botgets == "rock :shell:" && playergets == "paper :newspaper2:") {
              const wow = client.emojis.cache.find(emoji => emoji.name === "warn");
  
      embed.addField("Rock Beats paper Bot wins",wow)
  
  }
      
      if (botgets == "paper :newspaper2:" && playergets == "scissors :scissors:") {
        const wow = client.emojis.cache.find(emoji => emoji.name === "wow");
  
      embed.addField("Scissors Cuts paper " + message.author.username + " wins",wow)
  
  }
    
      if (botgets == "rock :shell:" && playergets == "scissors :scissors:") {
        const wow = client.emojis.cache.find(emoji => emoji.name === "blob_party");
  
      embed.addField("Rock Smashes Scissors Bot wins",wow)
  
  }
      
          if (botgets == "scissors :scissors:" && playergets == "rock :shell:") {
        const wow = client.emojis.cache.find(emoji => emoji.name === "thinky");
  
      embed.addField("Rock Smashes Scissors " + message.author.username + " wins",wow)
  
  }
      
              if (botgets == "scissors :scissors:" && playergets == "paper :newspaper2:") {
        const wow = client.emojis.cache.find(emoji => emoji.name === "thonk_gif");
  
      embed.addField("Scissors cuts Paper Bot wins",wow)
  
  }
  message.channel.send(embed)
  
}})
