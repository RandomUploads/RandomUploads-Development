# Mix it up bot

a simple discord bot which is fun to use.


<img src="https://cdn.discordapp.com/attachments/774847277092962345/774847506777374772/standard.gif">


## Installing Dependencies
#FOR LINUX
download all the files and then do the following commands

```bash
sudo chmod +x installdepends.sh
#this is for making the script executable
./installdepends.sh
```

#FOR WINDOWS
```
double click the installdepends.bat script to install all dependencies
```
## Usage

1. go to `config.js` and change the token and prefix of the bot in the location
2. Download the upload the emoji's to your server and change the name and id of them where they are used
2. After doing all of these stuff do the following to run the bot

#FOR LINUX
```bash
sudo chmod +x run.sh
#this is for making the script executable
./run.sh
```
#FOR WINDOWS
```
double click the run.bat script to start the bot
```
You need to have NodeJS installed!!!

Have fun playing with it :D 

Consider subscribing me on youtube by clicking the link [here](https://bit.ly/ReyanshKhobragade)
