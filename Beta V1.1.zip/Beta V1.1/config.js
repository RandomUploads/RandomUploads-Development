const config = {
    token: 'ODQxODE4MTQ1MDg1MzI1MzMz.YJsSPg.agSRpc8BMQwPN3TxRofypoqHwCI',
    prefix: '+'
}

module.exports = config;