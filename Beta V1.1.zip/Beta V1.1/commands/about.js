const config = require('../config')
const { MessageEmbed } = require("discord.js");

exports.run = async(client, message, args) => {
  let embed = new MessageEmbed()
  .addField('About Myself', 'A Simple Bot Made To Have Fun :D')
  .addField(`${config.prefix}` + 'help','to know more about the bot use commands ' + `${config.prefix}` + 'help')
  .addField(`${config.prefix}` + 'sysinfo','this shows system specifications     ' + `${config.prefix}` + 'sysinfo')
  .addField('Version', 'BETA 1.1 RandomUploads edition')
      .setColor("RANDOM")
      .setTimestamp()
      .setFooter(`${message.author.tag}`, message.author.displayAvatarURL())
  message.channel.send(embed)
  }
