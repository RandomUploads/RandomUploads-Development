const { MessageEmbed } = require("discord.js");

const os = require('os');

module.exports.run = async (client, message, args) => {

    let servercount = client.guilds.cache.size;
    let usercount = client.users.cache.size;
    let channelscount = client.channels.cache.size;
    let arch = os.arch();
    let platform = os.platform();
    let shard = client.ws.shards.size;
    let NodeVersion = process.version;
    let cores = os.cpus().length;

    let stats = new MessageEmbed()
    .setTitle(`System Information of ${client.user.username}`)
    .setColor('RED')
    .addField("Server Count", `${servercount}`, true)
    .addField("Users Count", `13`, true)
    .addField("Channel's Count", `${channelscount}`, true)
    .addField('Arch', `x86-64`, true)
    .addField('Base clocks', `1.9GHZ`, true)
    .addField('RAM', `4GB`, true)
    .addField('Cores', `6`, true)
    .addField('GPU', `Nvidia Quadro P1000`, true)
    .addField('Threads', `12`, true)
    .setTimestamp()
    .setFooter(`${message.author.tag}`, message.author.displayAvatarURL());
    message.channel.send(stats);
};

module.exports.help = {
    name: "stats"
}
