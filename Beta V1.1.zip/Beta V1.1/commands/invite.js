const { MessageEmbed } = require("discord.js");

exports.run = async(client, message, args) => {
  let embed = new MessageEmbed()
  .setTitle("My server invite pink :D")
  .setDescription("Thanks for inviting me to your server, see you there! :thumbsup:")
  .addField("Invite Link","https://discord.com/api/oauth2/authorize?client_id=841818145085325333&permissions=0&scope=bot")
         .setColor("GREEN")
         .setTimestamp()
         .setFooter(`${message.author.tag}`, message.author.displayAvatarURL())
    message.channel.send(embed)
}
