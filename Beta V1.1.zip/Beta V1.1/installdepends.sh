echo "Installing Dependencies =)"
npm install discord.js
npm install ytdl-core
npm install node-opus
npm install ffmpeg
npm install jimp
echo "Installed All Dependencies :D"
