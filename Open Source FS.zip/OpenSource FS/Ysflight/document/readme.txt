
YS Flight Simulator
Version 20181124

 By CaptainYS
  E-Mail PEB01130@nifty.com
  URL    http://www.ysflight.com



Japanese -> Please refer to jreadme.txt
English  -> Please refer to ereadme.txt



System requirement
  YSFLIGHT for Windows: Windows 7/8.x/10
    Probably Vista is good enough, but I cannot test to confirm.
  YSFLIGHT for Mac OSX: Intel Mac OS 10.12 or newer (need 64-bit CPU and OS)
    Probably earlier macOS is fine, but I cannot test to confirm.
  YSFLIGHT for Linux: Tested on Ubuntu 14
    Probably earlier Ubuntu is fine, but I cannot test to confirm.



