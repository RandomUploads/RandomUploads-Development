YS Flight Simulator
Version 20181124

 By CaptainYS
  E-Mail PEB01130@nifty.com
  URL    http://www.ysflight.com



Required Environment
  YSFLIGHT for Windows: Windows 7/8.x/10
    Probably Vista is good enough, but I cannot test to confirm.
  YSFLIGHT for Mac OSX: Intel Mac OS 10.12 or newer (need 64-bit CPU and OS)
    Probably earlier macOS is fine, but I cannot test to confirm.
  YSFLIGHT for Linux: Tested on Ubuntu 14
    Probably earlier Ubuntu is fine, but I cannot test to confirm.



Running the Program
[Mac OSX]
  If you extract the archive, you will get a bundle called YSFLIGHT.  Double click it to start the program.


[Windows]
In the directory where you extracted files, please find the following executable, and run one of them.

    ysflight32_gl1.exe
    ysflight32_gl2.exe
    ysflight32_d3d9.exe

You can get the highest quality from ysflight32_gl2.exe, however, it requires relatively a new and fast GPU.  Other executables, ysflight32_gl1.exe and ysflight32_d3d9.exe do not require as new and fast GPU, but the quality will be lower.




[Linux]
  Extract files, and type ysflight2 or ysflight from console, or double click to start the program.



THANK YOU FOR DOWNLOADING MY SOFTWARE.

    Soji Yamakawa
      PEB01130@nifty.com
      http://www.ysflight.com
